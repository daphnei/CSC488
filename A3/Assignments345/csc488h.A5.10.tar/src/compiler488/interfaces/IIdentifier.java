package compiler488.interfaces;

public interface IIdentifier extends IVisitableElement {
	/**
	 * @return the name of the routine
	 */
	public String getIdentifier();
}
